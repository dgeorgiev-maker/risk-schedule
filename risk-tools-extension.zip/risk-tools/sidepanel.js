const COLORS = ['#8AB4F8', '#C58AF9', '#81C995', '#FDD663', '#F28B82', '#78D9EC', '#FCAD70', '#FF8BCB'];
const DEFAULT = { groups: [
  { name: 'Risk', color: '#8AB4F8', open: true, items: [
    { title: 'График', url: 'https://dgeorgiev-maker.github.io/risk-schedule/' }
  ] }
] };
let data = null;
const $ = s => document.querySelector(s);
const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } };
const fav = u => { try { return 'https://www.google.com/s2/favicons?sz=32&domain=' + new URL(u).hostname; } catch (e) { return ''; } };
const save = () => chrome.storage.sync.set({ data });

async function load() {
  const r = await chrome.storage.sync.get('data');
  data = r.data || JSON.parse(JSON.stringify(DEFAULT));
  render();
}

function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'style') e.style.cssText = v;
    else e.setAttribute(k, v);
  }
  for (const k of kids) if (k != null) e.append(k);
  return e;
}

function render() {
  const list = $('#list'); list.textContent = '';
  data.groups.forEach((g, gi) => {
    const grp = el('section', { class: 'group' + (g.open ? '' : ' closed') });
    const toggle = () => { g.open = !g.open; save(); render(); };
    grp.append(el('div', { class: 'ghead', oncontextmenu: e => groupMenu(e, gi) },
      el('button', { class: 'caret', 'aria-label': g.open ? 'Скрий' : 'Покажи', onclick: toggle }, '▼'),
      el('button', { class: 'chip', style: 'background:' + g.color, onclick: toggle }, g.name),
      el('button', { class: 'plus', title: 'Добави линк', 'aria-label': 'Добави линк в ' + g.name, onclick: () => { g.open = true; render(); showForm(gi); } }, '+')
    ));
    const items = el('div', { class: 'items', id: 'items-' + gi });
    if (!g.items.length) items.append(el('div', { class: 'empty' }, 'Празно – натисни + за линк.'));
    g.items.forEach((it, ii) => {
      const img = el('img', { src: fav(it.url), alt: '' });
      img.addEventListener('error', () => img.style.visibility = 'hidden');
      items.append(el('button', { class: 'item', title: it.url, onclick: e => openLink(it.url, e), oncontextmenu: e => itemMenu(e, gi, ii) },
        img, el('span', {}, el('span', { class: 't' }, it.title), el('span', { class: 'u' }, host(it.url)))));
    });
    grp.append(items);
    list.append(grp);
  });
}

async function openLink(url, e) {
  const newTab = e && (e.ctrlKey || e.metaKey || e.button === 1);
  if (!newTab) {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const base = url.replace(/[#?].*$/, '').replace(/\/$/, '');
    const hit = tabs.find(t => t.url && t.url.replace(/[#?].*$/, '').replace(/\/$/, '') === base);
    if (hit) { chrome.tabs.update(hit.id, { active: true }); return; }
  }
  chrome.tabs.create({ url });
}

function showForm(gi, ii) {
  closeMenu();
  const box = $('#items-' + gi); if (!box) return;
  const ex = box.querySelector('form'); if (ex) ex.remove();
  const it = ii != null ? data.groups[gi].items[ii] : null;
  const title = el('input', { placeholder: 'Име, напр. График', value: it ? it.title : '' });
  const url = el('input', { placeholder: 'https://…', value: it ? it.url : '' });
  const f = el('form', {}, title, url, el('div', { class: 'frow' }, el('button', { class: 'ok', type: 'submit' }, it ? 'Запази' : 'Добави'), el('button', { class: 'ghost', type: 'button', onclick: () => f.remove() }, 'Откажи')));
  f.addEventListener('submit', ev => {
    ev.preventDefault();
    let u = url.value.trim(); if (!u) { url.focus(); return; }
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    const t = title.value.trim() || host(u);
    if (it) { it.title = t; it.url = u; } else data.groups[gi].items.push({ title: t, url: u });
    save(); render();
  });
  box.prepend(f); title.focus();
}

let menuEl = null;
function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
function menu(e, entries) {
  e.preventDefault(); closeMenu();
  menuEl = el('div', { class: 'menu', role: 'menu' }, ...entries.map(([label, fn, cls]) => el('button', { class: cls || '', onclick: () => { closeMenu(); fn(); } }, label)));
  document.body.append(menuEl);
  menuEl.style.left = Math.min(e.clientX, innerWidth - 160) + 'px';
  menuEl.style.top = Math.min(e.clientY, innerHeight - menuEl.offsetHeight - 8) + 'px';
}
function itemMenu(e, gi, ii) {
  const g = data.groups[gi];
  menu(e, [
    ['Промени', () => showForm(gi, ii)],
    ['Нагоре', () => { if (ii > 0) { [g.items[ii - 1], g.items[ii]] = [g.items[ii], g.items[ii - 1]]; save(); render(); } }],
    ['Изтрий', () => { if (confirm('Да изтрия ли „' + g.items[ii].title + '“?')) { g.items.splice(ii, 1); save(); render(); } }, 'del']
  ]);
}
function groupMenu(e, gi) {
  const g = data.groups[gi];
  menu(e, [
    ['Преименувай', () => { const n = prompt('Име на групата', g.name); if (n && n.trim()) { g.name = n.trim(); save(); render(); } }],
    ['Смени цвета', () => { g.color = COLORS[(COLORS.indexOf(g.color) + 1) % COLORS.length]; save(); render(); }],
    ['Нагоре', () => { if (gi > 0) { [data.groups[gi - 1], data.groups[gi]] = [data.groups[gi], data.groups[gi - 1]]; save(); render(); } }],
    ['Изтрий групата', () => { if (confirm('Да изтрия ли групата „' + g.name + '“ с всички линкове?')) { data.groups.splice(gi, 1); save(); render(); } }, 'del']
  ]);
}
document.addEventListener('click', e => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
$('#addGroup').addEventListener('click', () => {
  const n = prompt('Име на новата група', 'Дашборди'); if (!n || !n.trim()) return;
  data.groups.push({ name: n.trim(), color: COLORS[data.groups.length % COLORS.length], open: true, items: [] });
  save(); render();
});
load();
